// This file is part of OpenTSDB.
// Copyright (C) 2010-2012  The OpenTSDB Authors.
//
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 2.1 of the License, or (at your
// option) any later version.  This program is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser
// General Public License for more details.  You should have received a copy
// of the GNU Lesser General Public License along with this program.  If not,
// see <http://www.gnu.org/licenses/>.
package net.opentsdb.rollup;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.Objects;

import net.opentsdb.core.Aggregator;
import net.opentsdb.core.Aggregators;
import net.opentsdb.utils.DateTime;

/**
 * Holds information about a rollup interval and rollup aggregator.
 * Every RollupQuery object will have a valid RollupInterval and Aggregator
 */
public class RollupQuery {

  // TEMP
  public static final byte[] SUM = new byte[] { 's', 'u', 'm' };
  public static final byte[] COUNT = new byte[] { 'c', 'o', 'u', 'n', 't' };
  
  private final RollupInterval rollup_interval;
  private final Aggregator rollup_agg;
  private final Aggregator group_by;
  
  /** Rollup aggregate prefix along with the delimiter as byte array. It will be
   * the same for the same rollup aggregator, but is defined here to 
   * reduce the number of calculations at scan time*/
  private final byte[] agg_prefix;
  
  /** Initial downsampling interval form the user, will be used to 
   * downsample the lower sampling rate, if data is not available for the 
   * requested sampling rate. It is in milliseconds*/
  private final long sample_interval_ms;

  /**
   * Default constructor
   * @param rollup_interval RollupInterval object
   * @param rollup_agg Aggregator object
   * @param sample_interval_ms Initial downsaple interval in milliseconds
   * @param group_by Group by aggregation.
   * @throws IllegalStateException if rollup interval, rollup aggregator or 
   * group by aggregator is null
   */
  public RollupQuery(final RollupInterval rollup_interval, 
                     final Aggregator rollup_agg, 
                     long sample_interval_ms, 
                     final Aggregator group_by) {
    
    if (rollup_interval == null) {
      throw new IllegalStateException("Rollup interval is null");
    }
    if (rollup_agg == null) {
      throw new IllegalStateException("Rollup aggregator is null");
    }
    if (group_by == null) {
      throw new IllegalStateException("Group by aggregator is null");
    }
    
    this.rollup_interval = rollup_interval;
    // we need to convert zimsum => sum, mimmax => max, mimmin => min so that
    // we match properly on the column names
    if (rollup_agg == Aggregators.ZIMSUM) {
      this.rollup_agg = Aggregators.SUM;
    } else if (rollup_agg == Aggregators.MIMMAX) {
      this.rollup_agg = Aggregators.MAX;
    } else if (rollup_agg == Aggregators.MIMMIN) {
      this.rollup_agg = Aggregators.MIN;
    } else {
      this.rollup_agg = rollup_agg;
    }
    if (group_by == Aggregators.ZIMSUM) {
      this.group_by = Aggregators.SUM;
    } else if (group_by == Aggregators.MIMMAX) {
      this.group_by = Aggregators.MAX;
    } else if (group_by == Aggregators.MIMMIN) {
      this.group_by = Aggregators.MIN;
    } else {
      this.group_by = group_by;
    }
    if (group_by == Aggregators.AVG) {
      agg_prefix = RollupUtils.getRollupQualifierPrefix(
          Aggregators.SUM.toString());
    } else {
      agg_prefix = RollupUtils.getRollupQualifierPrefix(
          this.group_by.toString());
    }
    this.sample_interval_ms = sample_interval_ms;
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(rollup_interval, rollup_agg.toString());
  }
  
  @Override
  public boolean equals(final Object obj) {
    if (obj == null) {
      return false;
    }
    if (!(obj instanceof RollupQuery)) {
      return false;
    }
    if (obj == this) {
      return true;
    }
    final RollupQuery query = (RollupQuery)obj;
    return Objects.equal(rollup_agg, query.rollup_agg) 
        && rollup_interval.equals(query.rollup_interval);
  }
  
  @Override
  public String toString() {
    final StringBuilder buf = new StringBuilder();
    buf.append("rollup interval=")
        .append(rollup_interval.getInterval())
        .append(", rollup aggregator=")
        .append(rollup_agg.toString())
        .append(", group_by=")
        .append(group_by.toString());
    return buf.toString();
  }

  /**
   * @return the count of intervals in this span
   */
  public RollupInterval getRollupInterval() {
    return rollup_interval;
  }

  /**
   * @return the rollup aggregator
   */
  @JsonIgnore
  public Aggregator getRollupAgg() {
    return rollup_agg;
  }
  
  @JsonIgnore
  public Aggregator getGroupBy() {
    return group_by;
  }
  
  /**
   * Does it contain a valid rollup interval, mainly says it is not the default
   * rollup. Default rollup is of same resolution as raw data. So if true, 
   * which means the raw cell column qualifier is encoded with the aggregate 
   * function and the cell is not appended or compacted 
   * @param rollup_query related RollupQuery object, null if rollup is disabled
   * @return true if it is rollup query
   */
  public static boolean isValidQuery(final RollupQuery rollup_query) {
    return (rollup_query != null && rollup_query.rollup_interval != null &&
      !rollup_query.rollup_interval.isDefaultInterval());
  }
  
  /**
   * Rollup aggregate prefix
   * @return aggregate prefix along with the delimiter as byte array 
   */
  public byte[] getRollupAggPrefix() {
    return agg_prefix;
  }

  /** @return The sample interval in milliseconds. */
  public long getSampleIntervalInMS() {
    return sample_interval_ms;
  }
  
  /**
   * Tells whether the current rollup query sampling rate is lower than the
   * initial request
   * 
   * @return true if it is of lower sampling rate else false
   */
  public boolean isLowerSamplingRate() {
    return this.rollup_interval.getIntervalSeconds() * 1000 < sample_interval_ms;
  }

  /**
   * Looks at the SLA configured for the table to be queried and determines the
   * timestamp of the latest data point that is guaranteed to be covered by the
   * table.
   * @return last timestamp in seconds of the period guaranteed to be covered
   */
  public int getLastRollupTimestampSeconds() {
    return (int) (DateTime.currentTimeMillis()/1000 - getRollupInterval().getMaximumLag());
  }

  /**
   * Checks whether the passed timestamp is in the blackout period (between
   * the latest guaranteed timestamp and now)
   * @param timestampMillis The timestamp to check in milliseconds
   * @return whether the timestamp is in the blackout period
   */
  public boolean isInBlackoutPeriod(long timestampMillis) {
    long latestRollupPointTimestamp = DateTime.currentTimeMillis() - getRollupInterval().getMaximumLag()*1000L;

    return timestampMillis > latestRollupPointTimestamp;
  }
}
