<?php

function nvweb_twitter_timeline_twitter_timeline($block)
{
    // https://dev.twitter.com/web/embedded-timelines
    /*
        data-chrome="..."
        noheader: Hides the timeline header. Implementing sites must add their own Twitter attribution, link to the source timeline, and comply with other Twitter display requirements.
        nofooter: Hides the timeline footer and Tweet composer link, if included in the timeline widget type.
        noborders: Removes all borders within the widget including borders surrounding the widget area and separating Tweets.
        noscrollbar: Crops and hides the main timeline scrollbar, if visible. Please consider that hiding standard user interface components can affect the accessibility of your website.
        transparent: Removes the widget’s background color.
        data-tweet-limit="3"    max: 20
    */

    $data_chrome = '';
    $data_twitter_user = '';
    $theme = "";
    $links_color = "";
    $border_color = "";

    foreach($block->properties as $property)
    {
        switch($property->id)
        {
            case 'username':
                $data_twitter_user = $property->value;
                break;

            case 'widget_id':
                $data_widget_id = $property->value;
                break;

            case 'height':
                $height = $property->value;
                break;

            case 'theme':
                $theme = $property->value;
                break;

            case 'links_color':
                $links_color = $property->value;
                break;

            case 'border_color':
                $border_color = $property->value;
                break;

            case 'header':
                if(empty($property->value))
                    $data_chrome .= 'noheader ';
                break;

            case 'footer':
                if(empty($property->value))
                    $data_chrome .= 'nofooter ';
                break;

            case 'borders':
                if(empty($property->value))
                    $data_chrome .= 'noborders ';
                break;

            case 'scrollbar':
                if(empty($property->value))
                    $data_chrome .= 'noscrollbar ';
                break;

            case 'transparent_background':
                if(!empty($property->value))
                    $data_chrome .= 'transparent';
                break;
        }
    }

    // version with widget-id
    if(!empty($data_widget_id))
    {
        $out = '<a class="twitter-timeline" data-widget-id="' . $data_widget_id . '"  href="https://twitter.com/NavigateCMS"  data-chrome="' . $data_chrome . '" data-theme="' . $theme . '" data-link-color="' . $links_color . '" data-border-color="' . $border_color . '" height="' . $height . '">@' . $data_twitter_user . ' Tweets</a>';
        $out .= "\n";
        $out .= "<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','twitter-wjs');</script>";
    }
    else
    {
        // new version, widget-id not required
        $out = '<a class="twitter-timeline" href="https://twitter.com/'.$data_twitter_user.'"  data-chrome="' . $data_chrome . '" data-theme="' . $theme . '" data-link-color="' . $links_color . '" data-border-color="' . $border_color . '" height="' . $height . '">@' . $data_twitter_user . ' Tweets</a>';
        $out .= "\n";
        $out .= '<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>';

    }

    return $out;
}

?>